/**
 * Add Binary
 * https://leetcode.com/problems/add-binary/
 * **/
public class Main {
    public static void main(String[] args) {
        Solution s = new Solution();
        System.out.println(s.addBinary("1", "111"));
    }
}