/**
 * https://leetcode.com/problems/baseball-game/
 * baseball game
 * **/
public class Main {
    public static void main(String[] args) {
        Solution s = new Solution();
        String[] operations = {"1","C"};
        System.out.println(s.calPoints(operations));
    }
}