/**
 * H-index
 * https://school.programmers.co.kr/learn/courses/30/lessons/42747
 * **/
public class Main {
    public static void main(String[] args) {
        Solution s = new Solution();
        int[] citations = {10, 10, 10, 10, 10};
        System.out.println(s.solution(citations));
    }
}