/**
 * Remove all adjacent duplicates in string
 * https://leetcode.com/problems/remove-all-adjacent-duplicates-in-string/
 * **/
public class Main {
    public static void main(String[] args) {
        Solution s = new Solution();
        System.out.println(s.removeDuplicates("azxxzy"));
    }
}