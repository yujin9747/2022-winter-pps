/**
 * Excel sheet column title
 * https://leetcode.com/problems/excel-sheet-column-title/
 * **/
public class Main {
    public static void main(String[] args) {
        Solution s = new Solution();
        System.out.println(s.convertToTitle(701));
    }
}