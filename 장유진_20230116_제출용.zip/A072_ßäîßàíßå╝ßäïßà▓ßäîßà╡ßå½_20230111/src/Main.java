/**
 * Day of Year
 * https://leetcode.com/problems/day-of-the-year/
 *
 * https://en.wikipedia.org/wiki/Gregorian_calendar ->
 * **/
public class Main {
    public static void main(String[] args) {
        Solution s = new Solution();
        System.out.println(s.dayOfYear("2019-02-10"));
    }
}