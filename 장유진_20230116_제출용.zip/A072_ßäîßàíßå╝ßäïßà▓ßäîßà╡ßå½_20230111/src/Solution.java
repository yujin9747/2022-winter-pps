public class Solution {
    public int dayOfYear(String date) {
        DayOfYear dayOfYear = new DayOfYear();
        return dayOfYear.getDaysOfYear(date);
    }
}
