/**
 * Majority Element
 * https://leetcode.com/problems/majority-element/
 * **/
public class Main {
    public static void main(String[] args) {
        Solution s = new Solution();
        int[] nums = {2,2,1,1,1,2,2};
        System.out.println(s.majorityElement(nums));
    }
}