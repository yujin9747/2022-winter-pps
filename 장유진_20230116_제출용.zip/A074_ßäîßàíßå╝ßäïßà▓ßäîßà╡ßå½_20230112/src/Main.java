/**
 * Valid Palindrome
 * https://leetcode.com/problems/valid-palindrome/
 * **/
public class Main {
    public static void main(String[] args) {
        Solution s = new Solution();
        System.out.print(s.isPalindrome("0P"));
    }
}