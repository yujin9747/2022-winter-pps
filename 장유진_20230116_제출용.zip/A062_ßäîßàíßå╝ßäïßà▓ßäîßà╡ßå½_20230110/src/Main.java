/**
 * 2016년
 * https://school.programmers.co.kr/learn/courses/30/lessons/12901
 *
 * 2016년은 윤년
 * 한국법에서는, "윤년"이란 그레고리력에서 여분의 하루인 2월 29일을 추가하여 1년 동안 날짜의 수가 366일이 되는 해를 말한다(천문법 제2조 제5호).
 * 2016년 1월 1일은 금요일
 * **/
public class Main {
    public static void main(String[] args) {
        Solution s = new Solution();
        System.out.println(s.solution(5, 24));
    }
}