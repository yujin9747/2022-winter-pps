/**
 * 보물
 * https://www.acmicpc.net/problem/1026
 *
 * S = A[0] × B[0] + ... + A[N-1] × B[N-1]
 * s의 값을 최소화할 수 있도록 A를 재배열 할 것
 *
 * **/
public class Main {
    public static void main(String[] args) {

        Solution s = new Solution();
        s.solution();
    }
}