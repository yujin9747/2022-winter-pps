/**
 * 문자열 압축
 * https://school.programmers.co.kr/learn/courses/30/lessons/60057
 *
 * 가장 짧게 압축하고, 그 길이를 반환
 * **/
public class Main {
    public static void main(String[] args) {

        Solution s = new Solution();
        String str = "aabbaccc";
        System.out.println(s.solution(str));
    }
}