/**
 * https://www.acmicpc.net/problem/2920
 * 음계판별하기
 * 간단히 말해서 정렬 여부 판별하기
 * **/
public class Main {
    public static void main(String[] args) {

        Solution s = new Solution();
        String result = s.solution();
    }
}