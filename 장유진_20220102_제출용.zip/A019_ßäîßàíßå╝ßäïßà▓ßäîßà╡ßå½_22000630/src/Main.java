/**
 * 숫자의 개수
 * https://www.acmicpc.net/problem/2577
 *
 * **/
public class Main {
    public static void main(String[] args) {

        Solution s = new Solution();
        s.solution();
    }
}