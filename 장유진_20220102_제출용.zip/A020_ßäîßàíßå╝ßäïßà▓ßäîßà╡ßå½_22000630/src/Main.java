/**
 * 지능형 기차
 * https://www.acmicpc.net/problem/2455
 * **/
public class Main {
    public static void main(String[] args) {

        Solution s = new Solution();
        s.solution();
    }
}