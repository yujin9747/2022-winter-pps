/**
 * https://www.acmicpc.net/problem/4344
 * 평균은 넘겠지
 *
 * **/
public class Main {
    public static void main(String[] args) {
        Solution s = new Solution();
        s.solution();
    }
}