/**
 * valid perfect square
 * https://leetcode.com/problems/valid-perfect-square/
 * **/
public class Main {
    public static void main(String[] args) {
        Solution s = new Solution();
        System.out.println(s.isPerfectSquare(16));
    }
}