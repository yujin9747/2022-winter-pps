/**
 * Remove Outermost Parenthese
 * https://leetcode.com/problems/remove-outermost-parentheses/
 * **/
public class Main {
    public static void main(String[] args) {
        Solution s = new Solution();
        System.out.println(s.removeOuterParentheses("(()())(())(()(()))"));
    }
}