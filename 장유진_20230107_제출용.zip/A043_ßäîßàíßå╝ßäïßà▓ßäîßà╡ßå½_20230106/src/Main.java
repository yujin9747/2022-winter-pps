/**
 * Longest Common Prefix
 * https://leetcode.com/problems/longest-common-prefix/
 * **/
public class Main {
    public static void main(String[] args) {
        Solution s = new Solution();
        String[] strs = {"ab", "a"};
        System.out.println(s.longestCommonPrefix(strs));
    }
}