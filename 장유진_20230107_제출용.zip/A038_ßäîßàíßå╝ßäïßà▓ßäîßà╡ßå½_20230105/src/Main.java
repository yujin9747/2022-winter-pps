/**
 * Sqrt(x)
 * https://leetcode.com/problems/sqrtx/submissions/871856106/
 * **/
public class Main {
    public static void main(String[] args) {

        Solution s = new Solution();
        System.out.println(s.mySqrt(2147395600));
    }
}