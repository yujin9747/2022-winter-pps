/**
 * Backspace String compare
 * https://leetcode.com/problems/backspace-string-compare/
 * **/
public class Main {
    public static void main(String[] args) {
        Solution s = new Solution();
        System.out.println(s.backspaceCompare("ab##", "c#d#"));
    }
}