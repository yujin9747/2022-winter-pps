import java.util.Scanner;

public class Solution {
    public void solution(){
        Scanner s = new Scanner(System.in);
        double a = s.nextDouble();
        double b = s.nextDouble();
        Double sum = a + b;
        System.out.printf("%f", sum);
    }
}
