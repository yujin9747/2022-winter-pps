/**
 * 쿠키 구입
 * https://school.programmers.co.kr/learn/courses/30/lessons/49995
 * **/
public class Main {
    public static void main(String[] args) {

        Solution s = new Solution();
        int[] cookie = {1, 1, 2, 3};
        System.out.println(s.solution(cookie));
    }
}