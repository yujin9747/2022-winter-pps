/**
 * 핸드폰 요금
 * https://www.acmicpc.net/problem/1267
 * **/
public class Main {
    public static void main(String[] args) {

        Solution s = new Solution();
        s.solution();
    }
}