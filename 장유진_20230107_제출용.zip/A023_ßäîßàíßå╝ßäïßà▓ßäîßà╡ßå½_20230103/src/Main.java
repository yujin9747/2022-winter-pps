/**
 * Add Digits
 * https://leetcode.com/problems/add-digits/
 * **/
public class Main {
    public static void main(String[] args) {
        Solution s = new Solution();
        int result = s.addDigits(38);
        System.out.println(result);
    }
}