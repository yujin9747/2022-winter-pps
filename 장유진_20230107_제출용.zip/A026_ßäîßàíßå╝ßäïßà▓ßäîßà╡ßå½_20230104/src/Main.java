/**
 * 하샤드 수
 * https://school.programmers.co.kr/learn/courses/30/lessons/12947
 * 각 자리 수를 더한 값으로 원래의 값을 나눌 수 있으면 하샤드 수
 * **/
public class Main {
    public static void main(String[] args) {

        Solution s = new Solution();
        boolean result = s.solution(13);
        System.out.println(result);
    }
}