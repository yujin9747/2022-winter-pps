/**
 * 큰 수 만들기
 * https://school.programmers.co.kr/learn/courses/30/lessons/42883
 * 못 품 -> 다시 시도하기
 * **/
public class Main {
    public static void main(String[] args) {

        SolutionFail s = new SolutionFail();
        String result = s.solution("4177252841", 4);
        System.out.print(result);
    }
}